import React, { useContext, useRef, useState } from 'react'
import { UserContext } from '../Store'
import { useNavigate } from 'react-router-dom'

export default function Payment() {
    const store = useContext(UserContext)
    const [form, setForm] = useState({ cardHolderName: "", cardNumber: "", Expiry_Date_MM: "", Expiry_Date_YY: "", CVV: "", total: store.cartDetail.total })
    const cardHolderName = useRef()
    const cardNumber = useRef()
    const Expiry_Date_MM = useRef()
    const Expiry_Date_YY = useRef()
    const CVV = useRef()
    const navigate = useNavigate();
    let handleClick = (e) => {
        e.preventDefault();
        let user = localStorage.getItem("user")
        if (!user) return
        let userid = JSON.parse(user);
        if (form.total === 0)
            return
        cardHolderName.current.style.borderColor = "black"
        cardNumber.current.style.borderColor = "black"
        Expiry_Date_MM.current.style.borderColor = "black"
        Expiry_Date_YY.current.style.borderColor = "black"
        CVV.current.style.borderColor = "black"
        let isCorrect = true
        if (form.cardHolderName.length === 0) {
            cardHolderName.current.style.borderColor = "red";
            isCorrect = false;
        }
        if (form.cardNumber.length === 0 || !Number.isInteger(Number(form.cardNumber)) || form.cardNumber.length !== 16) {
            cardNumber.current.style.borderColor = "red";
            isCorrect = false;
        }

        if (form.Expiry_Date_MM.length === 0 || !Number.isInteger(Number(form.Expiry_Date_MM)) || form.Expiry_Date_MM.length !== 2) {
            Expiry_Date_MM.current.style.borderColor = "red";
            isCorrect = false;
        }

        if (form.Expiry_Date_YY.length === 0 || !Number.isInteger(Number(form.Expiry_Date_YY)) || form.Expiry_Date_YY.length !== 4) {
            Expiry_Date_YY.current.style.borderColor = "red";
            isCorrect = false;
        }

        if (form.CVV.length === 0 || !Number.isInteger(Number(form.CVV)) || form.CVV.length !== 3) {
            CVV.current.style.borderColor = "red";
            isCorrect = false;
        }
        console.log("s")
        if (!isCorrect) return;

        fetch(process.env.REACT_APP_API_KEY + "payment", {
            method: "POST",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ ...form, products: store.cartList, userid: userid._id }),
        }).then(
            (res) => {
                return res.json();
            }
        ).then((data) => {
            console.log(data)
            if (data.status) {
                setForm({ cardHolderName: "", cardNumber: "", Expiry_Date_MM: "", Expiry_Date_YY: "", CVV: "", total: 0 })
                store.setCartDetail({"subcost":0,"discount":0,"tax":0,"total":0})
                store.setcartList([])
                alert("Payment successful")
                navigate("/")
            }
            else {
                alert("error")
            }
        })
            .catch((err) => {
                console.log(err)
                alert("error")
            })

    }
    return (
        <div className='PaymentPage'>
            <div className="PaymentWindow">

                <img src="./I4.jpg" alt="..." className='PaymetLeftImg' />
                <form className="PaymentForm" onSubmit={(e) => {  handleClick(e) }}>
                    <p className='PaymentHeading'>Your details
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-chevron-right" viewBox="0 0 16 16">
                            <path fillRule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z" />
                        </svg>
                        <span>Payment</span>
                    </p>
                    <button className="BtnPymentApple">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-apple" viewBox="0 0 16 16">
                            <path d="M11.182.008C11.148-.03 9.923.023 8.857 1.18c-1.066 1.156-.902 2.482-.878 2.516.024.034 1.52.087 2.475-1.258.955-1.345.762-2.391.728-2.43Zm3.314 11.733c-.048-.096-2.325-1.234-2.113-3.422.212-2.189 1.675-2.789 1.698-2.854.023-.065-.597-.79-1.254-1.157a3.692 3.692 0 0 0-1.563-.434c-.108-.003-.483-.095-1.254.116-.508.139-1.653.589-1.968.607-.316.018-1.256-.522-2.267-.665-.647-.125-1.333.131-1.824.328-.49.196-1.422.754-2.074 2.237-.652 1.482-.311 3.83-.067 4.56.244.729.625 1.924 1.273 2.796.576.984 1.34 1.667 1.659 1.899.319.232 1.219.386 1.843.067.502-.308 1.408-.485 1.766-.472.357.013 1.061.154 1.782.539.571.197 1.111.115 1.652-.105.541-.221 1.324-1.059 2.238-2.758.347-.79.505-1.217.473-1.282Z" />
                            <path d="M11.182.008C11.148-.03 9.923.023 8.857 1.18c-1.066 1.156-.902 2.482-.878 2.516.024.034 1.52.087 2.475-1.258.955-1.345.762-2.391.728-2.43Zm3.314 11.733c-.048-.096-2.325-1.234-2.113-3.422.212-2.189 1.675-2.789 1.698-2.854.023-.065-.597-.79-1.254-1.157a3.692 3.692 0 0 0-1.563-.434c-.108-.003-.483-.095-1.254.116-.508.139-1.653.589-1.968.607-.316.018-1.256-.522-2.267-.665-.647-.125-1.333.131-1.824.328-.49.196-1.422.754-2.074 2.237-.652 1.482-.311 3.83-.067 4.56.244.729.625 1.924 1.273 2.796.576.984 1.34 1.667 1.659 1.899.319.232 1.219.386 1.843.067.502-.308 1.408-.485 1.766-.472.357.013 1.061.154 1.782.539.571.197 1.111.115 1.652-.105.541-.221 1.324-1.059 2.238-2.758.347-.79.505-1.217.473-1.282Z" />
                        </svg>
                        <span>Pay</span>
                    </button>
                    <button className="BtnPymentPayPal">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-paypal" viewBox="0 0 16 16">
                            <path d="M14.06 3.713c.12-1.071-.093-1.832-.702-2.526C12.628.356 11.312 0 9.626 0H4.734a.7.7 0 0 0-.691.59L2.005 13.509a.42.42 0 0 0 .415.486h2.756l-.202 1.28a.628.628 0 0 0 .62.726H8.14c.429 0 .793-.31.862-.731l.025-.13.48-3.043.03-.164.001-.007a.351.351 0 0 1 .348-.297h.38c1.266 0 2.425-.256 3.345-.91.379-.27.712-.603.993-1.005a4.942 4.942 0 0 0 .88-2.195c.242-1.246.13-2.356-.57-3.154a2.687 2.687 0 0 0-.76-.59l-.094-.061ZM6.543 8.82a.695.695 0 0 1 .321-.079H8.3c2.82 0 5.027-1.144 5.672-4.456l.003-.016c.217.124.4.27.548.438.546.623.679 1.535.45 2.71-.272 1.397-.866 2.307-1.663 2.874-.802.57-1.842.815-3.043.815h-.38a.873.873 0 0 0-.863.734l-.03.164-.48 3.043-.024.13-.001.004a.352.352 0 0 1-.348.296H5.595a.106.106 0 0 1-.105-.123l.208-1.32.845-5.214Z" />
                        </svg>
                        <span className='Pay'>Pay</span>
                        <span className='Pal'>Pal</span>
                    </button>
                    <p className='PaymetSec'>Or pay with diffirent method</p>
                    <div className="PaymentItem">
                        <label htmlFor="CardHolderName">Card Holder Name</label>
                        <div className="PAyIconInput">
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-person-vcard-fill" viewBox="0 0 16 16">
                                    <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4Zm9 1.5a.5.5 0 0 0 .5.5h4a.5.5 0 0 0 0-1h-4a.5.5 0 0 0-.5.5ZM9 8a.5.5 0 0 0 .5.5h4a.5.5 0 0 0 0-1h-4A.5.5 0 0 0 9 8Zm1 2.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 0-1h-3a.5.5 0 0 0-.5.5Zm-1 2C9 10.567 7.21 9 5 9c-2.086 0-3.8 1.398-3.984 3.181A1 1 0 0 0 2 13h6.96c.026-.163.04-.33.04-.5ZM7 6a2 2 0 1 0-4 0 2 2 0 0 0 4 0Z" />
                                </svg>
                            </span>
                            <input type="text" id='CardHolderName' placeholder='Card Holder Name' ref={cardHolderName} onChange={(e) => {
                                setForm({ ...form, cardHolderName: e.target.value })
                            }} />
                        </div>
                    </div>
                    <div className="PaymentItem">
                        <label htmlFor="CardNo">Credit card Number</label>
                        <div className="PAyIconInput">
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-credit-card-2-back-fill" viewBox="0 0 16 16">
                                    <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v5H0V4zm11.5 1a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h2a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-2zM0 11v1a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-1H0z" />
                                </svg>
                            </span>
                            <input type="text" id='CardNo' placeholder='XXXX XXXX XXXX XXXX' ref={cardNumber} onChange={(e) => {
                                setForm({ ...form, cardNumber: e.target.value })
                            }} />
                        </div>
                    </div>
                    <div className="PaymentItem2">
                        <div className="payItem1">
                            <label htmlFor="DateMM">Expiry Date</label>
                            <div className="DateItem">
                                <input type="text" id='DateMM' placeholder='MM' ref={Expiry_Date_MM} onChange={(e) => {
                                    setForm({ ...form, Expiry_Date_MM: e.target.value })
                                }} />
                                <input type="text" id='DateYY' placeholder='YYYY' ref={Expiry_Date_YY} onChange={(e) => {
                                    setForm({ ...form, Expiry_Date_YY: e.target.value })
                                }} />
                            </div>
                        </div>
                        <div className="payItem1">
                            <label htmlFor="CVV">CVV</label>
                            <div className="CVV">
                                <input type="text" id='CVV' placeholder='1 2 3' ref={CVV} onChange={(e) => {
                                    setForm({ ...form, CVV: e.target.value })
                                }} />
                                <span>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-credit-card-2-back-fill" viewBox="0 0 16 16">
                                        <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v5H0V4zm11.5 1a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h2a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-2zM0 11v1a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-1H0z" />
                                    </svg>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div className='PaymentData'>
                        <span>Subtotal</span>
                        <span className='PayB'><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-currency-rupee" viewBox="0 0 16 16">
                            <path d="M4 3.06h2.726c1.22 0 2.12.575 2.325 1.724H4v1.051h5.051C8.855 7.001 8 7.558 6.788 7.558H4v1.317L8.437 14h2.11L6.095 8.884h.855c2.316-.018 3.465-1.476 3.688-3.049H12V4.784h-1.345c-.08-.778-.357-1.335-.793-1.732H12V2H4v1.06Z" />
                        </svg>{store.cartDetail.subcost}</span>
                    </div>
                    <div className='PaymentData'>
                        <span>Discount</span>
                        <span className='PayB'><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-currency-rupee" viewBox="0 0 16 16">
                            <path d="M4 3.06h2.726c1.22 0 2.12.575 2.325 1.724H4v1.051h5.051C8.855 7.001 8 7.558 6.788 7.558H4v1.317L8.437 14h2.11L6.095 8.884h.855c2.316-.018 3.465-1.476 3.688-3.049H12V4.784h-1.345c-.08-.778-.357-1.335-.793-1.732H12V2H4v1.06Z" />
                        </svg>{store.cartDetail.discount}</span>
                    </div>
                    <div className='Payhr'></div>
                    <div className='PaymentData'>
                        <span>Total Amount</span>
                        <span className='PayB'><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-currency-rupee" viewBox="0 0 16 16">
                            <path d="M4 3.06h2.726c1.22 0 2.12.575 2.325 1.724H4v1.051h5.051C8.855 7.001 8 7.558 6.788 7.558H4v1.317L8.437 14h2.11L6.095 8.884h.855c2.316-.018 3.465-1.476 3.688-3.049H12V4.784h-1.345c-.08-.778-.357-1.335-.793-1.732H12V2H4v1.06Z" />
                        </svg>{store.cartDetail.total}</span>
                    </div>
                    <button className="BtnPymentPay" onClick={handleClick}>
                        <span>Pay</span>
                    </button>
                </form>
            </div>
        </div>
    )
}
